# Nathu Gram — Android App (WebView Wrapper)

Yeh project aapki website **http://nathugram.xyz/Script** ko ek native Android app ke roop mein pesh karta hai.

## Features
- Full WebView jo aapki poori website (login, signup, feed, chat, sab kuch) dikhata hai
- Splash screen brand color ke saath
- Pull-to-refresh
- Photo/video upload support (profile pic, post upload ke liye zaroori)
- Camera aur gallery access permission
- Offline hone par "no internet" screen aur retry button
- File download support (DownloadManager)
- Back button se WebView history navigate hoti hai (app band nahi hoti)
- Notification permission ready (Android 13+)

## APK kaise banayein (Build Steps)

1. **Android Studio** install karein (agar nahi hai): https://developer.android.com/studio
2. Is poore `NathuGram` folder ko Android Studio mein **Open** karein (File → Open).
3. Studio khud gradle sync kar lega (internet chahiye pehli baar).
4. Menu se: **Build → Generate Signed Bundle / APK → APK**
   - Naya keystore banayein (password yaad rakhein — Play Store update ke liye same keystore chahiye hamesha)
   - **release** build type chunein
5. APK yahan milegi: `app/release/app-release.apk`

Testing ke liye: **Run ▶** button se seedha apne phone/emulator par install karke chala sakte hain (usmein `app-debug.apk` banegi).

## Website URL change karni ho to
`app/src/main/res/values/strings.xml` file mein `base_url` line edit karein.

## Zaroori Note
- Yeh app sirf ek **wrapper** hai — saara data, login, features aapki website (Sngine-based script) se hi aa rahe hain. App ke features improve karne ke liye website ke backend/API mein badlav karna hoga.
- Agar aapne yeh script kisi marketplace (jaise CodeCanyon) se khareeda hai, to use resell/redistribute karne se pehle uski **license terms** zaroor check kar lein.
- App ka naam, icon, package ID (`com.nathugram.app`) `AndroidManifest.xml` aur `build.gradle` mein change kar sakte hain.
