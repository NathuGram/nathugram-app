# WebView + JS interface classes must be kept
-keepclassmembers class com.nathugram.app.* {
   public *;
}
